﻿namespace SG_BAMS.Deudores
{
    partial class Información_Deudores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblmontoinicial = new Krypton.Toolkit.KryptonLabel();
            btnaceptar = new Krypton.Toolkit.KryptonButton();
            label6 = new Label();
            label4 = new Label();
            fechafinal = new Krypton.Toolkit.KryptonMonthCalendar();
            lblnombre = new Krypton.Toolkit.KryptonLabel();
            lbliddeuda = new Krypton.Toolkit.KryptonLabel();
            label5 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            kryptonLabel8 = new Krypton.Toolkit.KryptonLabel();
            fechainicio = new Krypton.Toolkit.KryptonMonthCalendar();
            panel1 = new Panel();
            panel3 = new Panel();
            pictureBox1 = new PictureBox();
            pictureBox4 = new PictureBox();
            label7 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            SuspendLayout();
            // 
            // lblmontoinicial
            // 
            lblmontoinicial.Location = new Point(163, 183);
            lblmontoinicial.Margin = new Padding(3, 2, 3, 2);
            lblmontoinicial.Name = "lblmontoinicial";
            lblmontoinicial.Size = new Size(119, 23);
            lblmontoinicial.StateCommon.ShortText.Color1 = Color.Navy;
            lblmontoinicial.TabIndex = 204;
            lblmontoinicial.Values.Text = "xxx-xxx";
            // 
            // btnaceptar
            // 
            btnaceptar.Location = new Point(73, 238);
            btnaceptar.Margin = new Padding(3, 2, 3, 2);
            btnaceptar.Name = "btnaceptar";
            btnaceptar.OverrideDefault.Back.Color1 = Color.SkyBlue;
            btnaceptar.OverrideDefault.Back.Color2 = Color.White;
            btnaceptar.OverrideFocus.Back.Color1 = Color.SkyBlue;
            btnaceptar.OverrideFocus.Back.Color2 = Color.White;
            btnaceptar.Size = new Size(106, 29);
            btnaceptar.StateCommon.Back.Color1 = Color.SkyBlue;
            btnaceptar.StateCommon.Back.Color2 = Color.White;
            btnaceptar.StateCommon.Border.Rounding = 5F;
            btnaceptar.StateCommon.Content.ShortText.Color1 = Color.Navy;
            btnaceptar.StateCommon.Content.ShortText.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnaceptar.StateNormal.Back.Color1 = Color.SkyBlue;
            btnaceptar.StateNormal.Back.ColorStyle = Krypton.Toolkit.PaletteColorStyle.Solid;
            btnaceptar.StatePressed.Back.Color1 = Color.Transparent;
            btnaceptar.StatePressed.Back.Color2 = Color.Transparent;
            btnaceptar.TabIndex = 202;
            btnaceptar.Values.DropDownArrowColor = Color.Empty;
            btnaceptar.Values.Text = "Aceptar";
            btnaceptar.Click += btnaceptar_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Arial", 14.25F, FontStyle.Bold);
            label6.ForeColor = Color.Navy;
            label6.Location = new Point(617, 51);
            label6.Name = "label6";
            label6.Size = new Size(117, 22);
            label6.TabIndex = 201;
            label6.Text = "Fecha Final";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Arial", 14.25F, FontStyle.Bold);
            label4.ForeColor = Color.Navy;
            label4.Location = new Point(337, 52);
            label4.Name = "label4";
            label4.Size = new Size(122, 22);
            label4.TabIndex = 200;
            label4.Text = "Fecha Inicio";
            // 
            // fechafinal
            // 
            fechafinal.Enabled = false;
            fechafinal.Location = new Point(557, 77);
            fechafinal.Margin = new Padding(3, 2, 3, 2);
            fechafinal.MaxDate = new DateTime(2100, 12, 31, 0, 0, 0, 0);
            fechafinal.MinDate = new DateTime(2025, 1, 1, 0, 0, 0, 0);
            fechafinal.Name = "fechafinal";
            fechafinal.Size = new Size(230, 182);
            fechafinal.StateCheckedNormal.Day.Border.Rounding = 10F;
            fechafinal.TabIndex = 199;
            // 
            // lblnombre
            // 
            lblnombre.Location = new Point(163, 148);
            lblnombre.Margin = new Padding(3, 2, 3, 2);
            lblnombre.Name = "lblnombre";
            lblnombre.Size = new Size(119, 23);
            lblnombre.StateCommon.ShortText.Color1 = Color.Navy;
            lblnombre.TabIndex = 198;
            lblnombre.Values.Text = "xxx-xxx";
            // 
            // lbliddeuda
            // 
            lbliddeuda.Location = new Point(164, 112);
            lbliddeuda.Margin = new Padding(3, 2, 3, 2);
            lbliddeuda.Name = "lbliddeuda";
            lbliddeuda.Size = new Size(113, 23);
            lbliddeuda.StateCommon.ShortText.Color1 = Color.Navy;
            lbliddeuda.TabIndex = 197;
            lbliddeuda.Values.Text = "xxx-xxx";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Navy;
            label5.Location = new Point(53, 183);
            label5.Name = "label5";
            label5.Size = new Size(83, 20);
            label5.TabIndex = 196;
            label5.Text = "Monto Inicial";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(50, 148);
            label3.Name = "label3";
            label3.Size = new Size(57, 20);
            label3.TabIndex = 195;
            label3.Text = "Nombre";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(49, 112);
            label2.Name = "label2";
            label2.Size = new Size(63, 20);
            label2.TabIndex = 194;
            label2.Text = "ID deuda";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Arial", 17.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Navy;
            label1.Location = new Point(36, 54);
            label1.Name = "label1";
            label1.Size = new Size(229, 27);
            label1.TabIndex = 193;
            label1.Text = "Información deudor";
            // 
            // kryptonLabel8
            // 
            kryptonLabel8.Location = new Point(51, 174);
            kryptonLabel8.Margin = new Padding(3, 2, 3, 2);
            kryptonLabel8.Name = "kryptonLabel8";
            kryptonLabel8.Size = new Size(119, 23);
            kryptonLabel8.TabIndex = 192;
            kryptonLabel8.Values.Text = "";
            // 
            // fechainicio
            // 
            fechainicio.Enabled = false;
            fechainicio.Location = new Point(282, 77);
            fechainicio.Margin = new Padding(3, 2, 3, 2);
            fechainicio.MaxDate = new DateTime(2100, 12, 31, 0, 0, 0, 0);
            fechainicio.MinDate = new DateTime(2025, 1, 1, 0, 0, 0, 0);
            fechainicio.Name = "fechainicio";
            fechainicio.Size = new Size(230, 182);
            fechainicio.StateCheckedNormal.Day.Border.Rounding = 10F;
            fechainicio.TabIndex = 191;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Navy;
            panel1.Location = new Point(-11, 0);
            panel1.Margin = new Padding(3, 2, 3, 2);
            panel1.Name = "panel1";
            panel1.Size = new Size(912, 18);
            panel1.TabIndex = 189;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Navy;
            panel3.Location = new Point(0, 285);
            panel3.Margin = new Padding(3, 2, 3, 2);
            panel3.Name = "panel3";
            panel3.Size = new Size(920, 18);
            panel3.TabIndex = 188;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Navy;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(21, 312);
            pictureBox1.TabIndex = 187;
            pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackColor = Color.Navy;
            pictureBox4.Location = new Point(880, 0);
            pictureBox4.Margin = new Padding(3, 2, 3, 2);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(21, 301);
            pictureBox4.TabIndex = 186;
            pictureBox4.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Arial", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Navy;
            label7.Location = new Point(795, 254);
            label7.Name = "label7";
            label7.Size = new Size(84, 29);
            label7.TabIndex = 345;
            label7.Text = "BAMS";
            // 
            // Información_Deudores
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(900, 302);
            Controls.Add(label7);
            Controls.Add(lblmontoinicial);
            Controls.Add(btnaceptar);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(fechafinal);
            Controls.Add(lblnombre);
            Controls.Add(lbliddeuda);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(kryptonLabel8);
            Controls.Add(fechainicio);
            Controls.Add(panel1);
            Controls.Add(panel3);
            Controls.Add(pictureBox1);
            Controls.Add(pictureBox4);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Información_Deudores";
            ShowIcon = false;
            Load += Información_Deudores_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Krypton.Toolkit.KryptonLabel lblmontoinicial;
        private Krypton.Toolkit.KryptonButton btnaceptar;
        private Label label6;
        private Label label4;
        private Krypton.Toolkit.KryptonMonthCalendar fechafinal;
        private Krypton.Toolkit.KryptonLabel lblnombre;
        private Krypton.Toolkit.KryptonLabel lbliddeuda;
        private Label label5;
        private Label label3;
        private Label label2;
        private Label label1;
        private Krypton.Toolkit.KryptonLabel kryptonLabel8;
        private Krypton.Toolkit.KryptonMonthCalendar fechainicio;
        private Panel panel1;
        private Panel panel3;
        private PictureBox pictureBox1;
        private PictureBox pictureBox4;
        private Label label7;
    }
}