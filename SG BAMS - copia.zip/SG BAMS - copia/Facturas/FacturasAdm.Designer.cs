﻿namespace SG_BAMS
{
    partial class FacturasAdm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel2 = new Panel();
            label10 = new Label();
            kryptonButton14 = new Krypton.Toolkit.KryptonButton();
            label1 = new Label();
            btnnotificaciones = new Button();
            panel8 = new Panel();
            panel3 = new Panel();
            panel5 = new Panel();
            BtnVer = new Krypton.Toolkit.KryptonButton();
            BtnNueva = new Krypton.Toolkit.KryptonButton();
            dtpInicio = new DateTimePicker();
            dtpFin = new DateTimePicker();
            dgvFacturas = new DataGridView();
            txtBusqueda = new Krypton.Toolkit.KryptonTextBox();
            label5 = new Label();
            label6 = new Label();
            BtnRefrescar = new Button();
            label4 = new Label();
            panel9 = new Panel();
            label2 = new Label();
            btnReportes = new ReaLTaiizor.Controls.NightButton();
            btnPerfil = new ReaLTaiizor.Controls.NightButton();
            btnCerrar = new ReaLTaiizor.Controls.NightButton();
            btnBitacora = new ReaLTaiizor.Controls.NightButton();
            btnFacturas = new ReaLTaiizor.Controls.NightButton();
            btnCompra = new ReaLTaiizor.Controls.NightButton();
            btnClientes = new ReaLTaiizor.Controls.NightButton();
            btnInventario = new ReaLTaiizor.Controls.NightButton();
            btnProveedores = new ReaLTaiizor.Controls.NightButton();
            btnDeudores = new ReaLTaiizor.Controls.NightButton();
            btnMenu = new ReaLTaiizor.Controls.NightButton();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvFacturas).BeginInit();
            SuspendLayout();
            // 
            // panel2
            // 
            panel2.BackColor = Color.Navy;
            panel2.Location = new Point(5, 0);
            panel2.Margin = new Padding(3, 2, 3, 2);
            panel2.Name = "panel2";
            panel2.Size = new Size(1385, 18);
            panel2.TabIndex = 107;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Arial", 36F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.Navy;
            label10.Location = new Point(704, 39);
            label10.Name = "label10";
            label10.Size = new Size(225, 56);
            label10.TabIndex = 121;
            label10.Text = "Facturas";
            // 
            // kryptonButton14
            // 
            kryptonButton14.Location = new Point(380, 152);
            kryptonButton14.Margin = new Padding(3, 2, 3, 2);
            kryptonButton14.Name = "kryptonButton14";
            kryptonButton14.Size = new Size(0, 0);
            kryptonButton14.StateCommon.Border.Rounding = 100F;
            kryptonButton14.StateNormal.Back.Color1 = Color.SkyBlue;
            kryptonButton14.StateNormal.Back.ColorStyle = Krypton.Toolkit.PaletteColorStyle.Solid;
            kryptonButton14.TabIndex = 119;
            kryptonButton14.Values.DropDownArrowColor = Color.Empty;
            kryptonButton14.Values.Text = "";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(984, 606);
            label1.Name = "label1";
            label1.Size = new Size(0, 15);
            label1.TabIndex = 116;
            // 
            // btnnotificaciones
            // 
            btnnotificaciones.BackColor = Color.Transparent;
            btnnotificaciones.BackgroundImage = Properties.Resources.campana;
            btnnotificaciones.BackgroundImageLayout = ImageLayout.Stretch;
            btnnotificaciones.FlatAppearance.BorderColor = Color.White;
            btnnotificaciones.FlatAppearance.BorderSize = 0;
            btnnotificaciones.FlatStyle = FlatStyle.Flat;
            btnnotificaciones.ForeColor = Color.Navy;
            btnnotificaciones.Location = new Point(1311, 22);
            btnnotificaciones.Margin = new Padding(3, 2, 3, 2);
            btnnotificaciones.Name = "btnnotificaciones";
            btnnotificaciones.Size = new Size(52, 33);
            btnnotificaciones.TabIndex = 113;
            btnnotificaciones.UseVisualStyleBackColor = false;
            btnnotificaciones.Click += btnnotificaciones_Click;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Navy;
            panel8.Location = new Point(235, 16);
            panel8.Margin = new Padding(3, 2, 3, 2);
            panel8.Name = "panel8";
            panel8.Size = new Size(21, 664);
            panel8.TabIndex = 110;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Navy;
            panel3.Location = new Point(0, 662);
            panel3.Margin = new Padding(3, 2, 3, 2);
            panel3.Name = "panel3";
            panel3.Size = new Size(1390, 18);
            panel3.TabIndex = 111;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Navy;
            panel5.Location = new Point(0, 0);
            panel5.Margin = new Padding(3, 2, 3, 2);
            panel5.Name = "panel5";
            panel5.Size = new Size(21, 680);
            panel5.TabIndex = 109;
            // 
            // BtnVer
            // 
            BtnVer.Location = new Point(908, 602);
            BtnVer.Margin = new Padding(3, 2, 3, 2);
            BtnVer.Name = "BtnVer";
            BtnVer.OverrideDefault.Back.Color1 = Color.SkyBlue;
            BtnVer.OverrideDefault.Back.Color2 = Color.White;
            BtnVer.OverrideFocus.Back.Color1 = Color.SkyBlue;
            BtnVer.OverrideFocus.Back.Color2 = Color.White;
            BtnVer.Size = new Size(75, 45);
            BtnVer.StateCommon.Back.Color1 = Color.SkyBlue;
            BtnVer.StateCommon.Back.Color2 = Color.White;
            BtnVer.StateCommon.Border.Rounding = 5F;
            BtnVer.StateCommon.Content.ShortText.Color1 = Color.Navy;
            BtnVer.StateCommon.Content.ShortText.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnVer.StateNormal.Back.Color1 = Color.SkyBlue;
            BtnVer.StateNormal.Back.ColorStyle = Krypton.Toolkit.PaletteColorStyle.Solid;
            BtnVer.StatePressed.Back.Color1 = Color.Transparent;
            BtnVer.StatePressed.Back.Color2 = Color.Transparent;
            BtnVer.TabIndex = 142;
            BtnVer.Values.DropDownArrowColor = Color.Empty;
            BtnVer.Values.Text = "Ver";
            BtnVer.Click += BtnVer_Click;
            // 
            // BtnNueva
            // 
            BtnNueva.Location = new Point(673, 602);
            BtnNueva.Margin = new Padding(3, 2, 3, 2);
            BtnNueva.Name = "BtnNueva";
            BtnNueva.OverrideDefault.Back.Color1 = Color.SkyBlue;
            BtnNueva.OverrideDefault.Back.Color2 = Color.White;
            BtnNueva.OverrideFocus.Back.Color1 = Color.SkyBlue;
            BtnNueva.OverrideFocus.Back.Color2 = Color.White;
            BtnNueva.Size = new Size(196, 45);
            BtnNueva.StateCommon.Back.Color1 = Color.SkyBlue;
            BtnNueva.StateCommon.Back.Color2 = Color.White;
            BtnNueva.StateCommon.Border.Rounding = 5F;
            BtnNueva.StateCommon.Content.ShortText.Color1 = Color.Navy;
            BtnNueva.StateCommon.Content.ShortText.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnNueva.StateNormal.Back.Color1 = Color.SkyBlue;
            BtnNueva.StateNormal.Back.ColorStyle = Krypton.Toolkit.PaletteColorStyle.Solid;
            BtnNueva.StatePressed.Back.Color1 = Color.Transparent;
            BtnNueva.StatePressed.Back.Color2 = Color.Transparent;
            BtnNueva.TabIndex = 142;
            BtnNueva.Values.DropDownArrowColor = Color.Empty;
            BtnNueva.Values.Text = "Nueva Factura";
            BtnNueva.Click += BtnNueva_Click;
            // 
            // dtpInicio
            // 
            dtpInicio.Location = new Point(1053, 118);
            dtpInicio.Name = "dtpInicio";
            dtpInicio.Size = new Size(222, 23);
            dtpInicio.TabIndex = 143;
            // 
            // dtpFin
            // 
            dtpFin.CalendarForeColor = Color.Navy;
            dtpFin.Location = new Point(1053, 144);
            dtpFin.Name = "dtpFin";
            dtpFin.Size = new Size(222, 23);
            dtpFin.TabIndex = 143;
            // 
            // dgvFacturas
            // 
            dgvFacturas.BackgroundColor = Color.SkyBlue;
            dgvFacturas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvFacturas.Location = new Point(291, 180);
            dgvFacturas.Margin = new Padding(3, 2, 3, 2);
            dgvFacturas.Name = "dgvFacturas";
            dgvFacturas.RowHeadersWidth = 51;
            dgvFacturas.Size = new Size(1050, 407);
            dgvFacturas.TabIndex = 37;
            dgvFacturas.CellDoubleClick += dgvFacturas_CellDoubleClick;
            // 
            // txtBusqueda
            // 
            txtBusqueda.CueHint.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtBusqueda.Location = new Point(398, 137);
            txtBusqueda.Name = "txtBusqueda";
            txtBusqueda.Size = new Size(554, 30);
            txtBusqueda.StateCommon.Back.Color1 = Color.White;
            txtBusqueda.StateCommon.Border.Color1 = Color.Navy;
            txtBusqueda.StateCommon.Border.Rounding = 5F;
            txtBusqueda.StateCommon.Content.Color1 = Color.Gray;
            txtBusqueda.StateCommon.Content.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point, 0, true);
            txtBusqueda.TabIndex = 323;
            txtBusqueda.TextChanged += txtBusqueda_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial Narrow", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.Navy;
            label5.Location = new Point(990, 118);
            label5.Name = "label5";
            label5.Size = new Size(52, 23);
            label5.TabIndex = 329;
            label5.Text = "Inicial:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Navy;
            label6.Location = new Point(990, 140);
            label6.Name = "label6";
            label6.Size = new Size(56, 25);
            label6.TabIndex = 330;
            label6.Text = "Final:";
            // 
            // BtnRefrescar
            // 
            BtnRefrescar.BackgroundImage = Properties.Resources.refresh;
            BtnRefrescar.BackgroundImageLayout = ImageLayout.Stretch;
            BtnRefrescar.Location = new Point(1279, 131);
            BtnRefrescar.Margin = new Padding(3, 2, 3, 2);
            BtnRefrescar.Name = "BtnRefrescar";
            BtnRefrescar.Size = new Size(57, 33);
            BtnRefrescar.TabIndex = 331;
            BtnRefrescar.UseVisualStyleBackColor = true;
            BtnRefrescar.Click += BtnRefrescar_Click_1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Navy;
            label4.Location = new Point(290, 139);
            label4.Name = "label4";
            label4.Size = new Size(89, 24);
            label4.TabIndex = 353;
            label4.Text = "Buscar:";
            // 
            // panel9
            // 
            panel9.BackColor = Color.Navy;
            panel9.Location = new Point(1371, 0);
            panel9.Margin = new Padding(3, 2, 3, 2);
            panel9.Name = "panel9";
            panel9.Size = new Size(21, 690);
            panel9.TabIndex = 111;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.Navy;
            label2.Location = new Point(68, 41);
            label2.Name = "label2";
            label2.Size = new Size(117, 41);
            label2.TabIndex = 354;
            label2.Text = "BAMS";
            // 
            // btnReportes
            // 
            btnReportes.BackColor = Color.Transparent;
            btnReportes.DialogResult = DialogResult.None;
            btnReportes.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReportes.ForeColor = Color.SkyBlue;
            btnReportes.HoverBackColor = Color.Navy;
            btnReportes.HoverForeColor = Color.White;
            btnReportes.InterpolationType = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            btnReportes.Location = new Point(9, 454);
            btnReportes.MinimumSize = new Size(144, 47);
            btnReportes.Name = "btnReportes";
            btnReportes.NormalBackColor = Color.Navy;
            btnReportes.PixelOffsetType = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            btnReportes.PressedBackColor = Color.Navy;
            btnReportes.PressedForeColor = Color.White;
            btnReportes.Radius = 20;
            btnReportes.Size = new Size(215, 47);
            btnReportes.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            btnReportes.TabIndex = 355;
            btnReportes.Text = "Reportes";
            btnReportes.Click += btnReportes_Click;
            // 
            // btnPerfil
            // 
            btnPerfil.BackColor = Color.Transparent;
            btnPerfil.DialogResult = DialogResult.None;
            btnPerfil.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPerfil.ForeColor = Color.SkyBlue;
            btnPerfil.HoverBackColor = Color.Navy;
            btnPerfil.HoverForeColor = Color.White;
            btnPerfil.InterpolationType = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            btnPerfil.Location = new Point(9, 606);
            btnPerfil.MinimumSize = new Size(144, 47);
            btnPerfil.Name = "btnPerfil";
            btnPerfil.NormalBackColor = Color.Navy;
            btnPerfil.PixelOffsetType = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            btnPerfil.PressedBackColor = Color.Navy;
            btnPerfil.PressedForeColor = Color.White;
            btnPerfil.Radius = 20;
            btnPerfil.Size = new Size(215, 47);
            btnPerfil.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            btnPerfil.TabIndex = 364;
            btnPerfil.Text = "Perfil";
            btnPerfil.Click += btnPerfil_Click;
            // 
            // btnCerrar
            // 
            btnCerrar.BackColor = Color.Transparent;
            btnCerrar.DialogResult = DialogResult.None;
            btnCerrar.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCerrar.ForeColor = Color.SkyBlue;
            btnCerrar.HoverBackColor = Color.Navy;
            btnCerrar.HoverForeColor = Color.White;
            btnCerrar.InterpolationType = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            btnCerrar.Location = new Point(9, 556);
            btnCerrar.MinimumSize = new Size(144, 47);
            btnCerrar.Name = "btnCerrar";
            btnCerrar.NormalBackColor = Color.Navy;
            btnCerrar.PixelOffsetType = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            btnCerrar.PressedBackColor = Color.Navy;
            btnCerrar.PressedForeColor = Color.White;
            btnCerrar.Radius = 20;
            btnCerrar.Size = new Size(215, 47);
            btnCerrar.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            btnCerrar.TabIndex = 363;
            btnCerrar.Text = "Cerrar Sesión";
            btnCerrar.Click += btnCerrar_Click;
            // 
            // btnBitacora
            // 
            btnBitacora.BackColor = Color.Transparent;
            btnBitacora.DialogResult = DialogResult.None;
            btnBitacora.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBitacora.ForeColor = Color.SkyBlue;
            btnBitacora.HoverBackColor = Color.Navy;
            btnBitacora.HoverForeColor = Color.White;
            btnBitacora.InterpolationType = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            btnBitacora.Location = new Point(9, 505);
            btnBitacora.MinimumSize = new Size(144, 47);
            btnBitacora.Name = "btnBitacora";
            btnBitacora.NormalBackColor = Color.Navy;
            btnBitacora.PixelOffsetType = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            btnBitacora.PressedBackColor = Color.Navy;
            btnBitacora.PressedForeColor = Color.White;
            btnBitacora.Radius = 20;
            btnBitacora.Size = new Size(215, 47);
            btnBitacora.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            btnBitacora.TabIndex = 362;
            btnBitacora.Text = "Bitácora";
            btnBitacora.Click += btnBitacora_Click;
            // 
            // btnFacturas
            // 
            btnFacturas.BackColor = Color.SkyBlue;
            btnFacturas.DialogResult = DialogResult.None;
            btnFacturas.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnFacturas.ForeColor = Color.White;
            btnFacturas.HoverBackColor = Color.SkyBlue;
            btnFacturas.HoverForeColor = Color.White;
            btnFacturas.InterpolationType = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            btnFacturas.Location = new Point(9, 148);
            btnFacturas.MinimumSize = new Size(144, 47);
            btnFacturas.Name = "btnFacturas";
            btnFacturas.NormalBackColor = Color.SkyBlue;
            btnFacturas.PixelOffsetType = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            btnFacturas.PressedBackColor = Color.Navy;
            btnFacturas.PressedForeColor = Color.White;
            btnFacturas.Radius = 20;
            btnFacturas.Size = new Size(215, 47);
            btnFacturas.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            btnFacturas.TabIndex = 361;
            btnFacturas.Text = "Facturas";
            // 
            // btnCompra
            // 
            btnCompra.BackColor = Color.Transparent;
            btnCompra.DialogResult = DialogResult.None;
            btnCompra.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCompra.ForeColor = Color.SkyBlue;
            btnCompra.HoverBackColor = Color.Navy;
            btnCompra.HoverForeColor = Color.White;
            btnCompra.InterpolationType = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            btnCompra.Location = new Point(9, 199);
            btnCompra.MinimumSize = new Size(144, 47);
            btnCompra.Name = "btnCompra";
            btnCompra.NormalBackColor = Color.Navy;
            btnCompra.PixelOffsetType = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            btnCompra.PressedBackColor = Color.Navy;
            btnCompra.PressedForeColor = Color.White;
            btnCompra.Radius = 20;
            btnCompra.Size = new Size(215, 47);
            btnCompra.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            btnCompra.TabIndex = 360;
            btnCompra.Text = "Compras";
            btnCompra.Click += btnCompra_Click;
            // 
            // btnClientes
            // 
            btnClientes.BackColor = Color.Transparent;
            btnClientes.DialogResult = DialogResult.None;
            btnClientes.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnClientes.ForeColor = Color.SkyBlue;
            btnClientes.HoverBackColor = Color.Navy;
            btnClientes.HoverForeColor = Color.White;
            btnClientes.InterpolationType = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            btnClientes.Location = new Point(9, 249);
            btnClientes.MinimumSize = new Size(144, 47);
            btnClientes.Name = "btnClientes";
            btnClientes.NormalBackColor = Color.Navy;
            btnClientes.PixelOffsetType = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            btnClientes.PressedBackColor = Color.Navy;
            btnClientes.PressedForeColor = Color.White;
            btnClientes.Radius = 20;
            btnClientes.Size = new Size(215, 47);
            btnClientes.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            btnClientes.TabIndex = 359;
            btnClientes.Text = "Clientes";
            btnClientes.Click += btnClientes_Click;
            // 
            // btnInventario
            // 
            btnInventario.BackColor = Color.Transparent;
            btnInventario.DialogResult = DialogResult.None;
            btnInventario.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnInventario.ForeColor = Color.SkyBlue;
            btnInventario.HoverBackColor = Color.Navy;
            btnInventario.HoverForeColor = Color.White;
            btnInventario.InterpolationType = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            btnInventario.Location = new Point(9, 300);
            btnInventario.MinimumSize = new Size(144, 47);
            btnInventario.Name = "btnInventario";
            btnInventario.NormalBackColor = Color.Navy;
            btnInventario.PixelOffsetType = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            btnInventario.PressedBackColor = Color.Navy;
            btnInventario.PressedForeColor = Color.White;
            btnInventario.Radius = 20;
            btnInventario.Size = new Size(215, 47);
            btnInventario.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            btnInventario.TabIndex = 358;
            btnInventario.Text = "Inventario";
            btnInventario.Click += btnInventario_Click;
            // 
            // btnProveedores
            // 
            btnProveedores.BackColor = Color.Transparent;
            btnProveedores.DialogResult = DialogResult.None;
            btnProveedores.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnProveedores.ForeColor = Color.SkyBlue;
            btnProveedores.HoverBackColor = Color.Navy;
            btnProveedores.HoverForeColor = Color.White;
            btnProveedores.InterpolationType = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            btnProveedores.Location = new Point(9, 351);
            btnProveedores.MinimumSize = new Size(144, 47);
            btnProveedores.Name = "btnProveedores";
            btnProveedores.NormalBackColor = Color.Navy;
            btnProveedores.PixelOffsetType = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            btnProveedores.PressedBackColor = Color.Navy;
            btnProveedores.PressedForeColor = Color.White;
            btnProveedores.Radius = 20;
            btnProveedores.Size = new Size(215, 47);
            btnProveedores.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            btnProveedores.TabIndex = 357;
            btnProveedores.Text = "Proveedores";
            btnProveedores.Click += btnProveedores_Click;
            // 
            // btnDeudores
            // 
            btnDeudores.BackColor = Color.Transparent;
            btnDeudores.DialogResult = DialogResult.None;
            btnDeudores.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDeudores.ForeColor = Color.SkyBlue;
            btnDeudores.HoverBackColor = Color.Navy;
            btnDeudores.HoverForeColor = Color.White;
            btnDeudores.InterpolationType = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            btnDeudores.Location = new Point(9, 403);
            btnDeudores.MinimumSize = new Size(144, 47);
            btnDeudores.Name = "btnDeudores";
            btnDeudores.NormalBackColor = Color.Navy;
            btnDeudores.PixelOffsetType = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            btnDeudores.PressedBackColor = Color.Navy;
            btnDeudores.PressedForeColor = Color.White;
            btnDeudores.Radius = 20;
            btnDeudores.Size = new Size(215, 47);
            btnDeudores.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            btnDeudores.TabIndex = 356;
            btnDeudores.Text = "Deudores";
            btnDeudores.Click += btnDeudores_Click;
            // 
            // btnMenu
            // 
            btnMenu.BackColor = Color.Transparent;
            btnMenu.DialogResult = DialogResult.None;
            btnMenu.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMenu.ForeColor = Color.SkyBlue;
            btnMenu.HoverBackColor = Color.Navy;
            btnMenu.HoverForeColor = Color.White;
            btnMenu.InterpolationType = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            btnMenu.Location = new Point(9, 96);
            btnMenu.MinimumSize = new Size(144, 47);
            btnMenu.Name = "btnMenu";
            btnMenu.NormalBackColor = Color.Navy;
            btnMenu.PixelOffsetType = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            btnMenu.PressedBackColor = Color.Navy;
            btnMenu.PressedForeColor = Color.White;
            btnMenu.Radius = 20;
            btnMenu.Size = new Size(215, 47);
            btnMenu.SmoothingType = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            btnMenu.TabIndex = 365;
            btnMenu.Text = "Menu Principal";
            btnMenu.Click += btnMenu_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Arial Narrow", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.Navy;
            label3.Location = new Point(1106, 74);
            label3.Name = "label3";
            label3.Size = new Size(94, 37);
            label3.TabIndex = 324;
            label3.Text = "Fecha";
            label3.TextAlign = ContentAlignment.TopCenter;
            // 
            // FacturasAdm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1391, 680);
            Controls.Add(panel9);
            Controls.Add(label4);
            Controls.Add(BtnRefrescar);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(txtBusqueda);
            Controls.Add(dgvFacturas);
            Controls.Add(dtpFin);
            Controls.Add(dtpInicio);
            Controls.Add(BtnNueva);
            Controls.Add(BtnVer);
            Controls.Add(panel5);
            Controls.Add(panel2);
            Controls.Add(label10);
            Controls.Add(kryptonButton14);
            Controls.Add(label1);
            Controls.Add(btnnotificaciones);
            Controls.Add(panel8);
            Controls.Add(panel3);
            Controls.Add(label2);
            Controls.Add(btnReportes);
            Controls.Add(btnPerfil);
            Controls.Add(btnCerrar);
            Controls.Add(btnBitacora);
            Controls.Add(btnFacturas);
            Controls.Add(btnCompra);
            Controls.Add(btnClientes);
            Controls.Add(btnInventario);
            Controls.Add(btnProveedores);
            Controls.Add(btnDeudores);
            Controls.Add(btnMenu);
            Name = "FacturasAdm";
            ShowIcon = false;
            Load += FacturasAdm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvFacturas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel2;
        private Label label10;
        private Krypton.Toolkit.KryptonButton kryptonButton14;
        private Label label1;
        private Krypton.Toolkit.KryptonButton btnajustes;
        private Krypton.Toolkit.KryptonButton btncompras;
        private Krypton.Toolkit.KryptonButton btnadmin;
        private Button btnnotificaciones;
        private Panel panel8;
        private Panel panel3;
        private Panel panel5;
        private Krypton.Toolkit.KryptonButton BtnVer;
        private Krypton.Toolkit.KryptonButton BtnNueva;
        private DateTimePicker dtpInicio;
        private DateTimePicker dtpFin;
        private DataGridView dgvFacturas;
        private Krypton.Toolkit.KryptonTextBox txtBusqueda;
        private Label label5;
        private Label label6;
        private Button BtnRefrescar;
        private Label label4;
        private Panel panel9;
        private Label label2;
        private ReaLTaiizor.Controls.NightButton btnReportes;
        private ReaLTaiizor.Controls.NightButton btnPerfil;
        private ReaLTaiizor.Controls.NightButton btnCerrar;
        private ReaLTaiizor.Controls.NightButton btnBitacora;
        private ReaLTaiizor.Controls.NightButton btnFacturas;
        private ReaLTaiizor.Controls.NightButton btnCompra;
        private ReaLTaiizor.Controls.NightButton btnClientes;
        private ReaLTaiizor.Controls.NightButton btnInventario;
        private ReaLTaiizor.Controls.NightButton btnProveedores;
        private ReaLTaiizor.Controls.NightButton btnDeudores;
        private ReaLTaiizor.Controls.NightButton btnMenu;
        private Label label3;
    }
}